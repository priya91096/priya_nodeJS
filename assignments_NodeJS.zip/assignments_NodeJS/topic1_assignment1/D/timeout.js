
function message() {
		setTimeout(message,1500);
	console.log("Welcome to Node JS");
}

	message();




