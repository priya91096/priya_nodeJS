var http = require('http');
var dt = require('./Math');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write("Sum of 10 and 5 = " + dt.add(10,5)+"<br>");
	res.write("Difference of 10 and 5 = " + dt.sub(10,5)+"<br>");
	res.write("Product of 10 and 5 = " + dt.mul(10,5)+"<br>");
	res.write("10 divided by 5 = " + dt.div(10,5)+"<br>");
    res.end();
}).listen(8080);