var http = require('http');
var os = require('os');
http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/plain'});

console.log("Platform: " + os.platform());
console.log("HostName: " + os.hostname());
	res.end();
}).listen(8080);
