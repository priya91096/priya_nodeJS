var http = require('http');
var dt = require('./daysTill');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write("The number of days till christmas: " + dt.myDateTime(Date.parse("Dec 25,2018"))+"<br>");
   res.write("The number of days till mother's day: " + dt.myDateTime(Date.parse("May 13,2018")));
    res.end();
}).listen(8080);