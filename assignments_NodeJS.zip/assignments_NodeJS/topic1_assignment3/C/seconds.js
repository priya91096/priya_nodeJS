var fs = require('fs');
var s=365*24*60*60;
var str="Number of seconds in a year: "+s+"     ";
fs.appendFile('year.txt', str, function (err) {
  if (err) throw err;
  console.log('Saved!');
});
var c=s*10;
str="Number of seconds in a century: "+c+"\n";
fs.appendFile('year.txt', str, function (err) {
  if (err) throw err;
  console.log('Saved!');
});