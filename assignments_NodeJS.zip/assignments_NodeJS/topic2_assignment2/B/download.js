const request = require('request');
var fs=require('fs');	
request('https://www.w3schools.com', function(err, response, body) {  
fs.writeFile('myFile.txt', body, function (err) {
  if (err) throw err;
  console.log('Saved!');
});
})
