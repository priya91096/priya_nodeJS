var events = require('events');
var eventEmitter = new events.EventEmitter();

//Create an event handler:
var myEventHandler1 = function () {
  console.log('First Event');
}
var myEventHandler2 = function () {
  console.log('Second Event');
}
var myEventHandler3 = function () {
  console.log('Third Event');
}

//Assign the event handler to an event:
eventEmitter.on('one', myEventHandler1);
eventEmitter.on('two', myEventHandler2);
eventEmitter.on('three', myEventHandler3);
//Fire the 'scream' event:
eventEmitter.emit('one');
eventEmitter.emit('two');
eventEmitter.emit('three');